Edit .github/agents/implementation-planner.agent.md.

Make only these two targeted changes — touch nothing else:

1. Replace the entire "## Methodology: Planning Phase" section with:

## Methodology: Planning Phase
Invoke the /implementation-planner skill, passing the requirements document
or feature description provided by the user. The skill owns the step-by-step
procedure for exploring the codebase, structuring phases, applying conventions,
and saving the plan. Wait for the skill to finish, then present the plan to the
user and request explicit approval before proceeding.

2. Replace the entire "## Methodology: Implementation Phase" section with:

## Methodology: Implementation Phase
*Only after explicit user approval of the plan:*
Invoke the /implementation-executor skill, pointing it at the plan file
produced in the planning phase. The skill owns the step-by-step procedure
for executing phases in order, running tests after each phase, and producing
the final verification report.

All other sections — Behavioral Boundaries, Edge Case Handling,
Decision-Making Framework, Output Format, Quality Control Checkpoints,
and When to Ask for Clarification — must remain exactly as they are.