Create a repository skill at .github/skills/implementation-planner/SKILL.md.

The SKILL.md frontmatter must be:

  name: implementation-planner
  description: >
    Produces a structured, phase-by-phase implementation plan for this
    Spring Boot / Clean Architecture / DDD store project. Use this skill
    when the user asks to plan, design, or outline a feature, or when in
    /plan mode. No code is written — only a plan is produced.

The skill body must instruct Copilot to follow this workflow:

### Step 1 — Explore the codebase
- Read .github/copilot-instructions.md to refresh all conventions.
- Identify every aggregate, layer, and file affected by the feature.
- The four layers and their roles:
    domain/       — Pure Java entities, value objects, repository interfaces. Zero framework deps.
    application/  — Spring @Service. Orchestrates domain; owns use-case logic and app exceptions.
    api/          — Spring @RestController + DTOs. Thin: delegates to application services immediately.
    infrastructure/mongo/ — Spring Data MongoDB. Implements domain repository ports.
- Dependency rule: api → application → domain ← infrastructure.

### Step 2 — Produce an ordered set of phases
  Always order phases domain-first:
  1. Domain layer — new entities, value objects, repository interface changes, domain exceptions
  2. Application layer — service methods, app exceptions, PricingCalculator changes if needed
  3. API layer — controller endpoints, DTO records with static from() factory methods
  4. Infrastructure layer — XxxDocument, SpringDataXxxRepository, MongoXxxRepository changes

  Each phase must contain:
  - Title
  - Exact file paths to create or modify (using the project's package structure under
    src/main/java/com/demo/store/ and src/test/java/com/demo/store/)
  - What to add or change in each file, following these conventions:
      * Typed IDs: every aggregate root uses its own XxxId(String value) record; XxxId.newId() for UUID
      * Money: use Money.of(), Money.zero(), Money#add, Money#multiply; always EUR, scale 2 HALF_UP
      * Repository pattern: domain interface in domain/ package; three infra files per aggregate
        (XxxDocument, SpringDataXxxRepository, MongoXxxRepository)
      * DTOs: all records for one aggregate in a single api/dto/XxxDtos.java file
      * Exceptions: domain exceptions in the aggregate package; app exceptions in application/;
        register new exceptions in GlobalExceptionHandler with the correct HTTP status
      * Tests: givenXxx_whenYyy_thenZzz naming; domain tests are pure unit tests;
        application tests use @ExtendWith(MockitoExtension.class) and mock repositories;
        PricingCalculator is used directly, never mocked
  - Testable acceptance criteria (one per behaviour, phrased as givenXxx_whenYyy_thenZzz)
  - Dependencies on prior phases

### Step 3 — Save the plan
- Write the plan to the session plan file, or to a path the user specifies.
- End with a one-paragraph summary: number of phases, total files affected, key risks or open questions.
- Stop. Do not write any implementation code.