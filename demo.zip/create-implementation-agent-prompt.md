GOAL: an agent that takes a requirements document, produces an implementation
plan divided into small verifiable tasks, waits for my approval, then
implements the plan task by task.

FORMAT: YAML frontmatter with a trigger-shaped `description` (planning and
implementing from requirements or an approved plan) and
`tools: ['search', 'read', 'edit', 'terminal']`. Body sections: Role,
Context, Workflow, Constraints, Output.

CONTENT:
- Role: a senior engineer on this codebase. Priorities: correctness, minimal
  diffs, respecting the architecture (api -> application -> domain;
  infrastructure implements the domain's repository ports).
- Context: the requirements document it is given,
  .github/copilot-instructions.md, and the code areas the requirements
  touch — search first, read before editing.
- Workflow: 
1) map each requirement to the components it touches; 
2) write an implementation plan at docs/specs/<ticket-key>/plan.md — tasks in
  dependency order; each task states its goal, the exact files to touch,
  numbered steps, and the exact test command to verify it;
3) STOP and ask for approval of the plan; 
4) only after approval, implement task by task: write the test first for changed behavior, run ./mvnw test after every
  task, tick the task off in the plan before moving on.

- Constraints: never write code before the plan is approved; touch only the
  files the current task names; if a requirement or task is ambiguous, stop
  and ask instead of deciding; no new dependencies without asking.
- Output: the plan with all tasks ticked, a final green ./mvnw test, and a
  summary listing every changed file.

DEFINITION OF DONE: the file exists, matches the format, and the workflow has
an explicit approval gate between planning and implementation.