# Copilot Instructions

## Build & Run

```bash
# Start MongoDB
docker compose up -d

# Run the application
./mvnw spring-boot:run

# Build
./mvnw clean package

# Run all tests (no DB required — all tests are unit tests)
./mvnw test

# Run a single test class
./mvnw test -Dtest=OrderTest

# Run a single test method
./mvnw test -Dtest=CheckoutServiceTest#givenFilledCart_whenCheckout_thenOrderPlacedStockReducedCartCleared
```

MongoDB URI defaults to `mongodb://172.18.225.140:27017/store`; override with `SPRING_DATA_MONGODB_URI`.

## Architecture

Clean Architecture with DDD, structured into four layers:

```
domain/       — Pure Java. Entities, value objects, repository interfaces. Zero framework deps.
application/  — Spring @Service. Orchestrates domain objects; owns use-case logic and app exceptions.
api/          — Spring @RestController + DTOs. Thin: delegates immediately to application services.
infrastructure/mongo/ — Spring Data MongoDB. Implements domain repository ports.
```

**Dependency rule**: `api` → `application` → `domain` ← `infrastructure` (infrastructure depends on domain, never the reverse).

### Domain aggregates

| Aggregate | Root | Notable behaviour |
|-----------|------|-------------------|
| `product` | `Product` | `decreaseStock` / `increaseStock`, `canFulfill` |
| `cart`    | `Cart`    | Upserts by `ProductId`; `clear()` after checkout |
| `order`   | `Order`   | State machine: NEW → PAID → SHIPPED → DELIVERED |
| `customer`| `Customer`| Holds `Email` and `Address` value objects |

### Checkout flow (`CheckoutService`)
Two-pass design: **Pass 1** — load all products and verify stock for every cart item (abort on first failure, nothing written). **Pass 2** — decrease stock, build `OrderLine`s, persist `Order`, clear cart.

## Key Conventions

### Typed IDs
Every aggregate root has its own ID record, e.g., `ProductId(String value)`, `OrderId(String value)`. IDs are never raw `String`s in domain code. `XxxId.newId()` generates a new UUID-backed instance.

### Money
`Money` is a record: `BigDecimal amount` + `Currency currency`. Always EUR by default. Always scale 2, `HALF_UP`. Use `Money.of("9.99")`, `Money.zero()`, `Money#add`, `Money#multiply`. Stored in MongoDB as separate `amount` + `currency` fields (e.g., `priceAmount`, `priceCurrency`).

### Repository pattern
- Domain defines the port interface (e.g., `ProductRepository`) in the `domain/` package.
- `infrastructure/mongo/` contains three files per aggregate:
  - `XxxDocument` — MongoDB `@Document` mapping class (plain getters/setters, no domain logic).
  - `SpringDataXxxRepository` — Spring Data `MongoRepository<XxxDocument, String>` interface.
  - `MongoXxxRepository` — `@Repository` that implements the domain port; converts between domain objects and documents.

### DTOs
All request/response records for one aggregate live in a single file: `api/dto/XxxDtos.java`. Static `from(DomainObject)` factory methods on response records handle mapping.

### Exception mapping
Domain exceptions live in the aggregate package (e.g., `InsufficientStockException`, `IllegalOrderStateException`). Application exceptions live in `application/` (`NotFoundException`, `EmptyCartException`). `GlobalExceptionHandler` maps them to HTTP status codes:
- `NotFoundException`, `ItemNotInCartException` → 404
- `EmptyCartException`, `IllegalArgumentException` → 400
- `MethodArgumentNotValidException` → 400 (field-level messages joined by `;`)
- `InsufficientStockException`, `IllegalOrderStateException` → 409

### Test naming
Tests follow the `givenXxx_whenYyy_thenZzz` naming convention. Domain tests are pure unit tests. Application service tests use Mockito (`@ExtendWith(MockitoExtension.class)`) to mock repository dependencies — `PricingCalculator` is used directly (not mocked).

### PricingCalculator
The designated extension seam for future discounts and taxes. Always route total calculations through it rather than computing inline.
