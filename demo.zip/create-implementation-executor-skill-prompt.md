Create a repository skill at .github/skills/implementation-executor/SKILL.md.

The SKILL.md frontmatter must be:

  name: implementation-executor
  description: >
    Implements an existing plan file for this Spring Boot / Clean Architecture / DDD
    store project, phase by phase. Use this skill when the user says "implement the
    plan", "execute the plan", or references a plan.md. A plan file must already exist.

The skill body must instruct Copilot to follow this workflow:

### Step 1 — Read the plan in full
- Locate the plan file (session plan.md or path provided by user).
- Read every phase before writing a single line of code.
- Re-read .github/copilot-instructions.md to load all conventions.

### Step 2 — Execute phases in order, one at a time
  For each phase:
  a) Announce the phase title to the user before starting.
  b) Implement all file changes for the phase, strictly following these conventions:
       * Typed IDs: every aggregate root uses its own XxxId(String value) record; XxxId.newId() for UUID
       * Money: use Money.of(), Money.zero(), Money#add, Money#multiply; always EUR, scale 2 HALF_UP
       * Repository pattern: domain interface in domain/ package; three infra files per aggregate
         (XxxDocument, SpringDataXxxRepository, MongoXxxRepository)
       * DTOs: all records for one aggregate in a single api/dto/XxxDtos.java; use static from() factories
       * Exceptions: domain exceptions in the aggregate package; app exceptions in application/;
         register new exceptions in GlobalExceptionHandler with the correct HTTP status
       * Tests: givenXxx_whenYyy_thenZzz naming; domain tests are pure unit tests;
         application tests use @ExtendWith(MockitoExtension.class) and mock repositories;
         PricingCalculator is used directly, never mocked
       * Dependency rule: api → application → domain ← infrastructure; never cross this boundary
  c) Run the most targeted test command that covers this phase's changes:
         ./mvnw test -Dtest=XxxTest
     Fix any failures before moving to the next phase.
  d) Report the phase outcome to the user.

### Step 3 — Final validation
- After all phases complete, run the full test suite:
      ./mvnw test
- Report the final result.
- Do not deviate from the plan at any point without first asking the user.