---
title: Requirements for Allow customers to cancel an order before it ships
ticket: CR-142
date: 2026-07-17
---

## Summary

This change request allows customers to self-serve cancel an order, eliminating
the need for support to handle cancellations manually. Cancellation is only
permitted while the order has not yet shipped (status NEW or PAID). When an
order is cancelled, all stock quantities reserved at checkout must be released
back to the corresponding products. Attempting to cancel a shipped or delivered
order is a hard error.

## Requirements

**REQ-1:** As a customer, I can cancel an order in **NEW** status, so that the
order transitions to a cancelled state and is no longer active.
> _Criterion: Given an order with status NEW, when a cancel request is made,
> then the order status becomes CANCELLED._

**REQ-2:** As a customer, I can cancel an order in **PAID** status, so that the
order transitions to a cancelled state and is no longer active.
> _Criterion: Given an order with status PAID, when a cancel request is made,
> then the order status becomes CANCELLED._

**REQ-3:** As a customer, I cannot cancel an order that is in **SHIPPED**
status, and the system communicates this as an explicit error (not a silent
no-op).
> _Criterion: Given an order with status SHIPPED, when a cancel request is
> made, then the system returns an error response indicating the order cannot
> be cancelled._

**REQ-4:** As a customer, I cannot cancel an order that is in **DELIVERED**
status, and the system communicates this as an explicit error (not a silent
no-op).
> _Criterion: Given an order with status DELIVERED, when a cancel request is
> made, then the system returns an error response indicating the order cannot
> be cancelled._

**REQ-5:** When an order is successfully cancelled, the stock quantity for
every product referenced in the order's lines is restored by the exact
quantity that was reserved at checkout.
> _Criterion: Given an order with N units of product P, when the order is
> cancelled, then product P's available stock increases by N._

**REQ-6:** Stock restoration must cover all order lines — a cancellation
restores stock for every product in the order, not just a subset.
> _Criterion: Given an order with lines for products A and B, when the order
> is cancelled, then stock is restored for both A and B._

**REQ-7:** Requesting cancellation for an order that does not exist must
produce a clear "not found" error.
> _Criterion: Given an order ID that does not exist in the system, when a
> cancel request is made, then the system returns a not-found error._

**REQ-8 (implied):** A CANCELLED order must be a terminal state — no further
state transitions (e.g., PAID → CANCELLED → SHIPPED) are permitted from it,
and attempting to cancel an already-CANCELLED order is itself an error.
> _Criterion: Given an order with status CANCELLED, when any state-transition
> action is attempted (pay, ship, deliver, or cancel again), then the system
> returns an error._

**REQ-9 (implied):** Cancellation and stock restoration are atomic — if stock
restoration fails for any order line, the entire cancellation rolls back and
the order remains in its original status.
> _Criterion: Given an order whose cancellation triggers a stock-restoration
> failure on any line, then no stock is altered and the order status is
> unchanged._

**REQ-10 (implied):** If a product referenced in an order line no longer exists
at cancellation time, that line is silently skipped — stock restoration
proceeds for all remaining lines and the cancellation still succeeds.
> _Criterion: Given an order containing a line for a product that has since
> been deleted, when the order is cancelled, then the order status becomes
> CANCELLED and stock is restored for all other lines._

## Out of Scope

- Refund processing of any kind.
- Email or push notifications to the customer on cancellation.
- Admin or support-role cancellation (this ticket targets customer self-service only).
- Any cancellation reason or notes field.
- Partial cancellation (cancelling individual order lines rather than the whole order).

## Current vs New Behavior

### Current behavior

The order state machine supports only the following transitions:
`NEW → PAID → SHIPPED → DELIVERED`

There is no CANCELLED state. Stock reserved during checkout is permanently
held for the lifetime of the order. Customers cannot cancel orders themselves;
support handles cancellations manually, with no stock release.

### New behavior

A new `CANCELLED` terminal state is introduced. The allowed cancellation
transitions are:
- `NEW → CANCELLED`
- `PAID → CANCELLED`

On entering CANCELLED:
- All stock quantities reserved at checkout are released back to their
  respective products.

The following transitions must remain impossible:
- `SHIPPED → CANCELLED`
- `DELIVERED → CANCELLED`
- Any transition out of `CANCELLED`

### Existing behavior that must be preserved

- The `NEW → PAID → SHIPPED → DELIVERED` transitions must continue to work
  exactly as before.
- Stock decrease logic at checkout must not be affected.
- All other order operations (retrieve, list, pay, ship, deliver) must remain
  unchanged.

## Open Questions

1. ~~**Already-cancelled orders**~~ — Resolved: returns an error (captured in REQ-8).

2. ~~**Customer ownership / authorization**~~ — Resolved: no ownership check for now; any caller may cancel any order by ID.

3. ~~**Atomicity of stock restoration**~~ — Resolved: the operation is fully atomic; a failure on any line rolls back the entire cancellation (captured in REQ-9).

4. ~~**Stock restoration for deleted/missing products**~~ — Resolved: skip the missing product line and proceed; cancellation still succeeds (captured in REQ-10).
