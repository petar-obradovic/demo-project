# Implementation Plan: CR-142 — Allow Customers to Cancel an Order Before It Ships

**Source:** `docs/specs/CR-142/requirements.md`  
**Date:** 2026-07-17

---

## Overview

Introduces a `CANCELLED` terminal state to the order state machine. Cancellation is allowed from `NEW` or `PAID`; it is blocked from `SHIPPED`, `DELIVERED`, or `CANCELLED`. On successful cancellation, all per-line stock quantities are restored to their respective products; missing products are silently skipped (REQ-10).

No new aggregate, repository interface, infrastructure document class, or exception type is required — all additions slot into existing files.

---

## Phase 1 — Domain: OrderStatus and Order.cancel()

**Depends on:** nothing

### Files

#### `src/main/java/com/demo/store/domain/order/OrderStatus.java` _(modify)_

Add `CANCELLED` as the fifth enum constant:

```java
public enum OrderStatus {
    NEW, PAID, SHIPPED, DELIVERED, CANCELLED
}
```

#### `src/main/java/com/demo/store/domain/order/Order.java` _(modify)_

Add a `cancel()` method. Because cancellation allows two source states (`NEW` or `PAID`), it cannot reuse the single-status `requireStatus` helper; use an inline guard instead:

```java
public void cancel() {
    if (status != OrderStatus.NEW && status != OrderStatus.PAID) {
        throw new IllegalOrderStateException(status, "cancel");
    }
    status = OrderStatus.CANCELLED;
}
```

No changes are needed to the existing `markPaid/markShipped/markDelivered` methods or `requireStatus`. Those methods already check for a specific expected status; because `CANCELLED` is none of `NEW`, `PAID`, or `SHIPPED`, attempting any forward transition on a cancelled order will naturally throw `IllegalOrderStateException` — which covers REQ-8.

#### `src/test/java/com/demo/store/domain/order/OrderTest.java` _(modify)_

Add the following test cases (pure unit tests, no mocks):

| Test name | Covers |
|-----------|--------|
| `givenNewOrder_whenCancel_thenStatusCancelled` | REQ-1 |
| `givenPaidOrder_whenCancel_thenStatusCancelled` | REQ-2 |
| `givenShippedOrder_whenCancel_thenThrows` | REQ-3 |
| `givenDeliveredOrder_whenCancel_thenThrows` | REQ-4 |
| `givenCancelledOrder_whenAnyTransition_thenThrows` | REQ-8 |

---

## Phase 2 — Application: OrderService.cancel()

**Depends on:** Phase 1

### Files

#### `src/main/java/com/demo/store/application/OrderService.java` _(modify)_

1. Inject `ProductRepository` via constructor (add field + constructor parameter).
2. Add `cancel(OrderId id)` method implementing the following logic:

   ```
   1. Load order by id — throws NotFoundException if absent (REQ-7).
   2. Call order.cancel() — throws IllegalOrderStateException if status is
      SHIPPED, DELIVERED, or CANCELLED (REQ-3, REQ-4, REQ-8).
   3. For each OrderLine:
        a. Attempt productRepository.findById(line.productId()).
        b. If absent, skip (REQ-10).
        c. If present, call product.increaseStock(line.quantity()).
        d. Collect updated products.
   4. Save all updated products via productRepository.save(product)
      (stock restoration before order persistence — best-effort atomicity, REQ-9).
   5. Save and return the cancelled order via orderRepository.save(order).
   ```

   Signature: `public Order cancel(OrderId id)`

   The "save products before saving order" ordering is the closest approximation of REQ-9's atomicity guarantee available without distributed transactions: if a product save throws, the order document is never written to CANCELLED.

#### `src/test/java/com/demo/store/application/OrderServiceTest.java` _(modify)_

Add the following test cases (`@ExtendWith(MockitoExtension.class)`, mock `OrderRepository` and `ProductRepository`):

| Test name | Covers |
|-----------|--------|
| `givenNewOrder_whenCancel_thenCancelledAndStockRestored` | REQ-1, REQ-5 |
| `givenPaidOrder_whenCancel_thenCancelledAndStockRestored` | REQ-2 |
| `givenOrderWithMultipleLines_whenCancel_thenStockRestoredForAllLines` | REQ-6 |
| `givenUnknownOrder_whenCancel_thenNotFound` | REQ-7 |
| `givenShippedOrder_whenCancel_thenThrowsIllegalOrderState` | REQ-3 |
| `givenCancelledOrder_whenCancel_thenThrowsIllegalOrderState` | REQ-8 |
| `givenOrderWithMissingProduct_whenCancel_thenCancelSucceedsAndOtherStockRestored` | REQ-10 |

> **Note:** `PricingCalculator` is not involved in cancellation. Do not mock it.

---

## Phase 3 — API: Cancel endpoint on OrderController

**Depends on:** Phase 2

### Files

#### `src/main/java/com/demo/store/api/OrderController.java` _(modify)_

Add a new endpoint that delegates to `OrderService.cancel()`:

```java
@PostMapping("/{id}/cancel")
public OrderResponse cancel(@PathVariable String id) {
    return OrderResponse.from(orderService.cancel(new OrderId(id)));
}
```

HTTP method: `POST` (consistent with the existing `pay`, `ship`, `deliver` endpoints).  
Path: `/api/orders/{id}/cancel`  
Success status: `200 OK` (default; returns the updated `OrderResponse` with `status: "CANCELLED"`).  
Error mapping (already registered in `GlobalExceptionHandler` — **no changes needed**):

| Exception | HTTP |
|-----------|------|
| `NotFoundException` | 404 |
| `IllegalOrderStateException` | 409 |

#### No DTO changes required

`OrderResponse.from(Order)` serialises `order.status().name()`, so `"CANCELLED"` is emitted automatically once the enum constant exists.

#### No infrastructure changes required

`OrderDocument.status` is a plain `String`; `"CANCELLED"` round-trips without any code change. `MongoOrderRepository` and `MongoProductRepository` are unchanged.

---

## Affected Files Summary

| File | Action |
|------|--------|
| `src/main/java/com/demo/store/domain/order/OrderStatus.java` | Add `CANCELLED` constant |
| `src/main/java/com/demo/store/domain/order/Order.java` | Add `cancel()` method |
| `src/test/java/com/demo/store/domain/order/OrderTest.java` | Add 5 cancel test cases |
| `src/main/java/com/demo/store/application/OrderService.java` | Inject `ProductRepository`; add `cancel()` |
| `src/test/java/com/demo/store/application/OrderServiceTest.java` | Add 7 cancel service test cases |
| `src/main/java/com/demo/store/api/OrderController.java` | Add `POST /{id}/cancel` endpoint |

**Total: 6 files modified, 0 files created.**

---

## Risks & Open Questions

1. **Atomicity (REQ-9):** Without MongoDB multi-document transactions, the "save products → save order" ordering gives best-effort but not true atomicity. If a product save succeeds but a subsequent one throws, stock for the first product is already incremented and the order is not yet CANCELLED. This is an architectural constraint of the current stack; true atomicity would require enabling MongoDB transactions. This risk is acceptable per the current architecture and out-of-scope for the ticket.

2. **`OrderService` constructor change:** Adding `ProductRepository` to `OrderService`'s constructor will require updating the Spring context. Because `OrderService` is `@Service`, Spring will inject it automatically — no manual wiring changes needed. However, if any existing tests construct `OrderService` directly (e.g., `new OrderService(orderRepository)`), those will fail to compile and must be updated to pass a `ProductRepository` mock.
